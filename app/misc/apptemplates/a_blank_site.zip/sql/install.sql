create table A00 (id int,name varchar(255));
