<?php
if(!defined('ROOT')) exit('No direct script access allowed');

if(isset($_REQUEST['action'])) {
	
} else {
	printErr("NotSupported","Requested Widget Not Defined");
}
exit();
?>
